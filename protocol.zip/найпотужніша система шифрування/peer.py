import sys
import uuid
import requests
import threading
import time
import json

TRACKER_URL = 'http://127.0.0.1:9000'
CHAT_ID = 'global'
ANNOUNCE_INTERVAL = 30
POLL_INTERVAL = 2

PEER_ID = str(uuid.uuid4())
PEERS = {}  # peer_id: (ip, port)

# Announce себе на трекер
def announce():
    data = {
        'chat_id': CHAT_ID,
        'peer_id': PEER_ID,
        'ip': '',
        'port': '',
        'pubkey': ''
    }
    try:
        requests.post(f'{TRACKER_URL}/announce', json=data, timeout=3)
    except Exception:
        pass

def get_peers():
    try:
        r = requests.get(f'{TRACKER_URL}/get_peers', params={'chat_id': CHAT_ID}, timeout=3)
        peers = r.json()['peers']
        return {p['peer_id']: (p['ip'], p['port']) for p in peers if p['peer_id'] != PEER_ID}
    except Exception:
        return {}

def send_message_to_peer(peer_id, msg):
    data = {
        'to_peer': peer_id,
        'from_peer': PEER_ID,
        'text': msg
    }
    try:
        requests.post(f'{TRACKER_URL}/send_message', json=data, timeout=3)
    except Exception:
        pass

def periodic_announce():
    while True:
        announce()
        time.sleep(ANNOUNCE_INTERVAL)

def poll_messages():
    while True:
        try:
            r = requests.get(f'{TRACKER_URL}/get_messages', params={'peer_id': PEER_ID}, timeout=5)
            msgs = r.json().get('messages', [])
            for m in msgs:
                print(f"\n[{m['from'][:8]}] {m['text']}\n> ", end='', flush=True)
        except Exception:
            pass
        time.sleep(POLL_INTERVAL)

def main():
    global TRACKER_URL, PEERS
    if len(sys.argv) >= 2:
        TRACKER_URL = sys.argv[1]
    else:
        TRACKER_URL = 'http://127.0.0.1:9000'
    announce()
    PEERS = get_peers()
    threading.Thread(target=periodic_announce, daemon=True).start()
    threading.Thread(target=poll_messages, daemon=True).start()
    print(f"Your peer_id: {PEER_ID}")
    print(f"Current tracker: {TRACKER_URL}")
    print("Type your messages. Ctrl+C to exit.")
    print("Change tracker: /tracker <url>")
    while True:
        msg = input("> ")
        if msg.startswith('/tracker '):
            TRACKER_URL = msg.split(' ', 1)[1].strip()
            print(f"[INFO] Tracker changed to {TRACKER_URL}")
            announce()
            PEERS = get_peers()
            continue
        announce()
        PEERS = get_peers()
        for peer_id in PEERS:
            send_message_to_peer(peer_id, msg)

if __name__ == "__main__":
    main() 