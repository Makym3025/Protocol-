import requests
import sys
import os
import random
from protocol.chunk import Chunk
from protocol.crypto_utils import generate_rsa_keypair, serialize_public_key, deserialize_public_key, encrypt_with_public_key, decrypt_with_private_key, serialize_private_key, deserialize_private_key
from protocol.chunker import split_message_into_chunks, assemble_chunks
import hashlib
import time
import base64

# --- Вибір трекера ---
if len(sys.argv) > 1:
    TRACKER_URL = sys.argv[1]
else:
    TRACKER_URL = 'http://127.0.0.1:9000'

# --- Генерація/завантаження ключів ---
def load_or_generate_keys():
    if os.path.exists('peer_private.pem') and os.path.exists('peer_public.pem'):
        with open('peer_private.pem', 'rb') as f:
            priv = deserialize_private_key(f.read())
        with open('peer_public.pem', 'rb') as f:
            pub = deserialize_public_key(f.read())
    else:
        priv, pub = generate_rsa_keypair()
        with open('peer_private.pem', 'wb') as f:
            f.write(serialize_private_key(priv))
        with open('peer_public.pem', 'wb') as f:
            f.write(serialize_public_key(pub))
    return priv, pub

# --- Для ідентифікації: hash від публічного ключа ---
def get_recipient_id(pubkey_bytes: bytes) -> str:
    return hashlib.sha256(pubkey_bytes).hexdigest()

# --- Реєстрація username ---
def register_username(username, recipient_id, pubkey_pem):
    data = {'username': username, 'recipient_id': recipient_id, 'pubkey': base64.b64encode(pubkey_pem).decode()}
    r = requests.post(f'{TRACKER_URL}/register_username', json=data)
    return r.json()

# --- Lookup username ---
def lookup_username(username):
    r = requests.get(f'{TRACKER_URL}/lookup_username', params={'username': username})
    if r.status_code == 200:
        d = r.json()
        d['pubkey'] = base64.b64decode(d['pubkey'])
        return d
    return None

# --- Відправка chunk'а ---
def send_chunk_to_tracker(recipient_id: str, chunk: Chunk):
    data = {'recipient_id': recipient_id, 'chunk': chunk.to_dict()}
    r = requests.post(f'{TRACKER_URL}/chunk', json=data)
    return r.json()

# --- Отримання chunk'ів ---
def fetch_chunks_from_tracker(recipient_id: str):
    r = requests.get(f'{TRACKER_URL}/chunks', params={'recipient_id': recipient_id})
    return r.json().get('chunks', [])

# --- Relay-логіка ---
def relay_chunk(chunk_dict, my_id):
    chunk = Chunk.from_dict(chunk_dict)
    if chunk.recipient_id != my_id:
        return  # не для мене
    # Якщо я relay, пересилаю далі
    if chunk.current_hop < len(chunk.route) - 1:
        chunk.current_hop += 1
        chunk.recipient_id = chunk.route[chunk.current_hop]
        send_chunk_to_tracker(chunk.recipient_id, chunk)
        print(f'Relayed chunk {chunk.message_id}:{chunk.chunk_index} to {chunk.recipient_id}')
    else:
        print(f'Received my chunk {chunk.message_id}:{chunk.chunk_index}')
        return chunk
    return None

# --- Формування маршруту ---
def form_route(all_peers, recipient_id, num_relays=2):
    relays = [pid for pid in all_peers if pid != recipient_id]
    route = random.sample(relays, min(num_relays, len(relays))) if relays else []
    route.append(recipient_id)
    return route

# --- Основний цикл ---
if __name__ == '__main__':
    priv, pub = load_or_generate_keys()
    pub_bytes = serialize_public_key(pub)
    my_id = get_recipient_id(pub_bytes)
    print(f'Your peer_id: {my_id}')

    # --- Вибір username ---
    username = input('Enter your username: ').strip()
    reg = register_username(username, my_id, pub_bytes)
    if reg.get('status') != 'ok':
        print(f"Registration failed: {reg}")
        sys.exit(1)
    print(f'Registered as {username}')

    # --- Головне меню ---
    while True:
        print('\n1. Send message')
        print('2. Poll and relay/receive messages')
        print('3. Exit')
        choice = input('> ').strip()
        if choice == '1':
            to_username = input('To username: ').strip()
            info = lookup_username(to_username)
            if not info:
                print('User not found!')
                continue
            recipient_id = info['recipient_id']
            recipient_pubkey = deserialize_public_key(info['pubkey'])
            # --- Отримати список relay-peer'ів (всіх, крім себе і отримувача) ---
            # Для демо: отримуємо всіх зареєстрованих юзерів
            all_peers = []
            try:
                # Хак: отримати всіх юзерів через lookup (тільки для демо, у продакшн треба окремий endpoint)
                for test_name in ['vasya', 'petro', username, to_username]:
                    d = lookup_username(test_name)
                    if d and d['recipient_id'] not in all_peers:
                        all_peers.append(d['recipient_id'])
            except:
                pass
            route = form_route(all_peers, recipient_id)
            print(f'Route: {route}')
            message = input('Message: ')
            ciphertext = encrypt_with_public_key(recipient_pubkey, message.encode())
            message_id = hashlib.sha256(ciphertext).hexdigest()
            chunks = split_message_into_chunks(message_id, ciphertext)
            for chunk in chunks:
                chunk.chunk_type = 'data'
                chunk.route = route
                chunk.current_hop = 0
                chunk.recipient_id = route[0]
                send_chunk_to_tracker(chunk.recipient_id, chunk)
            print(f'Sent {len(chunks)} encrypted chunks for message_id {message_id}')
        elif choice == '2':
            print('Polling for chunks (Ctrl+C to stop)...')
            received = {}
            try:
                while True:
                    chunks = fetch_chunks_from_tracker(my_id)
                    for chunk_dict in chunks:
                        chunk = relay_chunk(chunk_dict, my_id)
                        if chunk:
                            # Це мій chunk, збираємо
                            if chunk.message_id not in received:
                                received[chunk.message_id] = {}
                            received[chunk.message_id][chunk.chunk_index] = chunk
                            # Якщо всі chunk'и зібрані — розшифрувати
                            if len(received[chunk.message_id]) == chunk.total_chunks:
                                ordered = [received[chunk.message_id][i] for i in range(chunk.total_chunks)]
                                ciphertext = assemble_chunks(ordered)
                                plaintext = decrypt_with_private_key(priv, ciphertext)
                                print(f'--- Decrypted message: {plaintext.decode()} ---')
                                del received[chunk.message_id]
                    time.sleep(2)
            except KeyboardInterrupt:
                print('Stopped polling.')
        elif choice == '3':
            break
        else:
            print('Invalid choice!') 