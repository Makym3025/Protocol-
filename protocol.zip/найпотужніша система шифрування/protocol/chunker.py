from typing import List
from .chunk import Chunk

CHUNK_SIZE = 256  # bytes, можна змінити


def split_message_into_chunks(message_id: str, ciphertext: bytes) -> List[Chunk]:
    total_chunks = (len(ciphertext) + CHUNK_SIZE - 1) // CHUNK_SIZE
    chunks = []
    for i in range(total_chunks):
        start = i * CHUNK_SIZE
        end = start + CHUNK_SIZE
        payload = ciphertext[start:end]
        checksum = Chunk.calculate_checksum(payload)
        chunk = Chunk(
            message_id=message_id,
            chunk_index=i,
            total_chunks=total_chunks,
            payload=payload,
            checksum=checksum,
            padding=Chunk.make_padding(0)  # можна додати padding
        )
        chunks.append(chunk)
    return chunks


def assemble_chunks(chunks: List[Chunk]) -> bytes:
    # Перевіряємо цілісність і порядок
    chunks_sorted = sorted(chunks, key=lambda c: c.chunk_index)
    for c in chunks_sorted:
        if c.checksum != Chunk.calculate_checksum(c.payload):
            raise ValueError(f"Checksum mismatch in chunk {c.chunk_index}")
    return b''.join(c.payload for c in chunks_sorted) 