import random
from typing import List

# Список онлайн relay-юзерів (peer_id або адреси)
# У реальному коді це буде отримуватись з трекера або peer discovery
ONLINE_RELAYS: List[str] = []


def choose_next_relay(exclude: List[str] = None) -> str:
    """Вибирає випадкового relay, не включаючи exclude."""
    candidates = [r for r in ONLINE_RELAYS if not exclude or r not in exclude]
    if not candidates:
        raise Exception("No available relays")
    return random.choice(candidates)


def relay_chunk(chunk_dict: dict, send_func, exclude: List[str] = None):
    """
    Приймає chunk (dict), вибирає наступного relay і пересилає chunk через send_func.
    send_func(next_relay, chunk_dict) — функція для відправки chunk'а.
    """
    next_relay = choose_next_relay(exclude)
    send_func(next_relay, chunk_dict) 