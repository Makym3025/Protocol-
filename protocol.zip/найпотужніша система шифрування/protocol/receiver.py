from .chunker import assemble_chunks
from .crypto_utils import decrypt_with_private_key
from .chunk import Chunk
from typing import List


def receive_and_decrypt_message(chunks: List[Chunk], recipient_privkey) -> str:
    ciphertext = assemble_chunks(chunks)
    plaintext = decrypt_with_private_key(recipient_privkey, ciphertext)
    return plaintext.decode() 