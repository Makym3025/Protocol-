import hashlib
import base64
import os
from dataclasses import dataclass, asdict, field
from typing import List

@dataclass
class Chunk:
    message_id: str
    chunk_index: int
    total_chunks: int
    payload: bytes
    checksum: str
    chunk_type: str = "data"  # data, relay, ack, dummy
    recipient_id: str = ""     # для кого цей chunk (поточний hop)
    route: List[str] = field(default_factory=list)  # маршрут relay
    current_hop: int = 0  # індекс у маршруті
    padding: bytes = b''

    def to_dict(self):
        d = asdict(self)
        d['payload'] = base64.b64encode(self.payload).decode()
        d['padding'] = base64.b64encode(self.padding).decode()
        d['route'] = self.route
        return d

    @staticmethod
    def from_dict(d):
        return Chunk(
            message_id=d['message_id'],
            chunk_index=d['chunk_index'],
            total_chunks=d['total_chunks'],
            payload=base64.b64decode(d['payload']),
            checksum=d['checksum'],
            chunk_type=d.get('chunk_type', 'data'),
            recipient_id=d.get('recipient_id', ''),
            route=d.get('route', []),
            current_hop=d.get('current_hop', 0),
            padding=base64.b64decode(d.get('padding', ''))
        )

    @staticmethod
    def calculate_checksum(payload: bytes) -> str:
        return hashlib.sha256(payload).hexdigest()

    @staticmethod
    def make_padding(size: int) -> bytes:
        return os.urandom(size) 