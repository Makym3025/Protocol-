import hashlib
from .crypto_utils import encrypt_with_public_key
from .chunker import split_message_into_chunks
from .chunk import Chunk
from typing import List


def make_message_id(ciphertext: bytes) -> str:
    return hashlib.sha256(ciphertext).hexdigest()


def prepare_chunks_for_sending(plaintext: str, recipient_pubkey, chunk_size=256) -> List[Chunk]:
    ciphertext = encrypt_with_public_key(recipient_pubkey, plaintext.encode())
    message_id = make_message_id(ciphertext)
    chunks = split_message_into_chunks(message_id, ciphertext)
    return chunks

# Далі можна додати функцію для маршрутизації chunk'ів через relay-юзерів 