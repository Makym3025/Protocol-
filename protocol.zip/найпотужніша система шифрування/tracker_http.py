from flask import Flask, request, jsonify
from collections import defaultdict

app = Flask(__name__)

# recipient_id -> list of chunk dicts
chunk_queues = defaultdict(list)
# username -> {'recipient_id': ..., 'pubkey': ...}
username_map = {}

@app.route('/chunk', methods=['POST'])
def receive_chunk():
    data = request.get_json()
    recipient_id = data.get('recipient_id')
    chunk = data.get('chunk')
    if not recipient_id or not chunk:
        return jsonify({'status': 'error', 'reason': 'missing fields'}), 400
    chunk_queues[recipient_id].append(chunk)
    return jsonify({'status': 'ok'})

@app.route('/chunks', methods=['GET'])
def get_chunks():
    recipient_id = request.args.get('recipient_id')
    if not recipient_id:
        return jsonify({'status': 'error', 'reason': 'missing recipient_id'}), 400
    chunks = chunk_queues[recipient_id]
    chunk_queues[recipient_id] = []  # clear after fetch
    return jsonify({'chunks': chunks})

@app.route('/register_username', methods=['POST'])
def register_username():
    data = request.get_json()
    username = data.get('username')
    recipient_id = data.get('recipient_id')
    pubkey = data.get('pubkey')
    if not username or not recipient_id or not pubkey:
        return jsonify({'status': 'error', 'reason': 'missing fields'}), 400
    if username in username_map:
        return jsonify({'status': 'error', 'reason': 'username taken'}), 409
    username_map[username] = {'recipient_id': recipient_id, 'pubkey': pubkey}
    return jsonify({'status': 'ok'})

@app.route('/lookup_username', methods=['GET'])
def lookup_username():
    username = request.args.get('username')
    if not username or username not in username_map:
        return jsonify({'status': 'error', 'reason': 'not found'}), 404
    return jsonify(username_map[username])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9000) 